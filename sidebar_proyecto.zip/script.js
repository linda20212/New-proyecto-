document.getElementById("resizeBtn").addEventListener("click", () => {
  document.body.classList.toggle("sb-expanded");
});
